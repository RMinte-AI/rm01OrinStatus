# WS-DATA-CLOSEOUT-v1.0 最小证据包

当前候选只证明本地F1/F2关闭及原回归，不是部署、设备、风扇或热模型证明。先读根目录收尾报告与docs/WS_DATA_V1.md。

完整校验：在本目录运行 `shasum -a 256 -c checksums.sha256`。用独立Python3.12环境和主机cc编译器重跑：

```sh
python3.12 -m venv /tmp/ws-closeout-review-env
/tmp/ws-closeout-review-env/bin/python -m pip install -r evidence/closeout/dependencies-lock.txt
/tmp/ws-closeout-review-env/bin/python scripts/verify_ws_data_offline.py --output /tmp/ws-closeout-review-results
```

依赖准备可以访问软件包源，不接设备。重跑仅--no-index/--no-deps安装包内唯一wheel到干净目录；当前7份源/标记与src逐字核对，运行原56项＋新增54项，共110项，再做C读取、实际Socket.IO编码容量、有界资源和实际导入身份复核。

测试隔离：每例清理TEGRASTATS环境；禁止网络连接/监听、真实采集与真实ModelMonitor。明确例外只有测试自建的受控Python输出/CLI子进程、主机C编译/解析程序；Python假输出命令是固定内联脚本，不是tegrastats，持有确切PID、有限等待并回收。SIGTERM仅发给自建测试子进程自己，不使用pkill。不能运行整个tests目录、live脚本、安装/全验证脚本或现场服务命令。

当前身份与结果：
- evidence/closeout/identity-before.json：与附件核对的上轮候选指纹。
- evidence/closeout/identity-final.json：当前源码/安装包身份、原56＋新54计数，以及server和数据函数不变证据。
- evidence/closeout/results和test-final.txt：当前源码110项及F1/F2输出。
- evidence/closeout/installed-results和installed-replay.txt：干净目录安装后110项、C/资源/消息大小、loaded_source.json、wheel_identity.json。
- evidence/ws-data/wheel：唯一当前候选（仍1.0.1，不是旧wheel）。
- closeout.patch：相对上轮候选的本轮源码/测试/文档增量；可在上轮ZIP副本复放。
- changes.patch：相对最初HEAD的累计最终修改；可在独立4a765acc基线用git apply --check复核。
- src、tests/offline、固定样例、必要客户端C引用/stub与来源SHA：全部可独立复核，不依赖作者临时目录或天山OS仓库。

F1/F2修改前复现（预期反例，不是当前候选验收）：

```sh
/tmp/ws-closeout-review-env/bin/python tests/offline/reproduce_closeout_before.py /tmp/ws-closeout-before-results
```

它使用evidence/closeout/before四份保存源码：真实Python输出管道未关闭，环境3000而旧CLI仍命令1000。所有自建子进程在结束/超时时回收。F1修复后两类故障也使用真实管道，保留外部强引用，不调用GC。

原始main反例源码在evidence/ws-data/baseline；更早R1诊断所需四份源在revision-baseline。原完整历史报告/ZIP/失败仍在工作树备份，包内只保留指纹与必要复现输入，不嵌套旧大包。当前接受依据只看closeout路径；failures.md标明本轮97/108/109阶段结果和夹具设置错误，不掩盖失败。

config预览显示本次环境/参数，不查询systemd运行状态。log_file未接线、不创建文件日志。环境现在开始生效是部署变化，手动卡要求核对实际服务环境、强制重装同版本包、检查导入SHA和明确回退对象；本轮不执行这些现场步骤。

资源数字属于macOS主机；客户端核心C读取通过不是ESP32接收超大帧或设备风扇通过。超过既有接收容量的报文限制如实保留。请把复核输出写到包外新目录，避免覆盖原证据。
